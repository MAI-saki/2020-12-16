package datas.domain;

import java.util.Date;

public class AccountRecord {

	private String transactionId;// ����ID
	private String transactionType;// ��������
	private String userAccount; // �����˺�
	private String receivableAccount; // �տ��˺�
	private String sourceAccount;// ��Դ�˺�
	private float transactionMoney;// ����Ǯ��
	private float accountBalance;// �˻����
	private Date transactionTime;// ����ʱ��

	public AccountRecord() {
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionAccount() {
		return userAccount;
	}

	public void setTransactionAccount(String transactionAccount) {
		this.userAccount = transactionAccount;
	}

	public String getReceivableAccount() {
		return receivableAccount;
	}

	public void setReceivableAccount(String receivableAccount) {
		this.receivableAccount = receivableAccount;
	}

	public String getSourceAccount() {
		return sourceAccount;
	}

	public void setSourceAccount(String sourceAccount) {
		this.sourceAccount = sourceAccount;
	}

	public float getTransactionMoney() {
		return transactionMoney;
	}

	public void setTransactionMoney(float transactionMoney) {
		this.transactionMoney = transactionMoney;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Date getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(Date transactionTime) {
		this.transactionTime = transactionTime;
	}

	@Override
	public String toString() {
		return "AccountRecord [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", userAccount=" + userAccount + ", receivableAccount=" + receivableAccount + ", sourceAccount="
				+ sourceAccount + ", transactionMoney=" + transactionMoney + ", accountBalance=" + accountBalance
				+ ", transactionTime=" + transactionTime + "]";
	}
}